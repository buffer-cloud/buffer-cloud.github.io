# Rev A fabrication data

Generated from `MCU Datalogger.kicad_pcb` with KiCad 9.

- Two copper layers. Finished outline: 52.1 × 34.9 mm.
- Gerber X2: F/B copper, F/B solder mask, F/B silkscreen, F/B paste, Edge.Cuts.
- Excellon metric absolute-coordinate drills, separated PTH and NPTH; PDF drill maps included.
- Copper clearance 0.20 mm; track width minimum 0.25 mm; copper-to-edge 0.30 mm.
- The drawing origin is preserved consistently across Gerbers and drill files.
- Inspect fabrication layers and confirm manufacturer's capabilities before ordering.
- Board thickness, copper weight, surface finish and mask color are order parameters; images do not specify a fabrication order.
- No fabrication, assembly, firmware or bench-test claim is made by this release.
